=== Live Messages ===
Contributors: Rajesh Benjwal
Tags: messages, live updates, tweets
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin for displaying live updating short messages like tweets.

== Description ==
Live Messages allows users to post short messages that update in real-time. Features include:
* Short message posting
* Three layout options (Classic, Grid, Compact)
* Character limit
* Edit and delete functionality
* Pagination
* Admin settings

== Installation ==
1. Upload the 'live-messages' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the plugin in Settings > Live Messages
4. Add the shortcode [live_messages] to any page or post

== Changelog ==
= 1.0 =
* Initial release 